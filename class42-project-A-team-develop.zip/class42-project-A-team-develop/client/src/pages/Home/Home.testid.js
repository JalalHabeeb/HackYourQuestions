import createTestIdFilePath from "../../util/createTestIdFilePath";

const TEST_ID = {
  container: `${createTestIdFilePath("pages", "Home", "Home")}-container`,
};

export default TEST_ID;
